expected = "a"
actual = "b"
list = ['c', 'd']

# Lặp từ 0 - 9 rồi làm gì đấy
for index in range(0, 10):
	# Gì đấy
	print(index)

num_items = 10000
loaded = 10	
# Nếu điều kiện chưa thỏa mãn thì làm gì đấy
while (loaded < num_items):
	# Gì đấy
	loaded = loaded + 100000
	print('hẹ hẹ')

print(f"Giá trị của tên là {expected} {actual}, {list}")
print("Giá trị tên là:", expected, actual, list)
print("Giá trị tên là: {} {} {}".format(expected , actual, str.join(',', list)))