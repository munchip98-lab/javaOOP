def is_integer(value):
	try:
		int_value = int(value)
		return isinstance(int_value, int)
	except ValueError:
		return False

## Call API và lấy kết quả
def sum_to_n(n):
	if not is_integer(n):
		return 0
	if int(n) > 10000:
		return 0
	# Đặt 1 biến đẻ lưu tổng giá trị muốn in ra
	sum = 0
	# Chạy vòng lặp từ 1 đến n và cộng vào biến tổng
	for index in range(1, int(n) + 1):
		sum = sum + index
	return sum

## Load tất cả dòng trông 1 file ra biến lines
with open('test_case.txt') as file:
	## Với mỗi dòng trong file, bỏ dấu trắng ở 2 đầu 
	## và lưu thành 1 phần tử trong mảng lines
	lines = [line.rstrip() for line in file]

## Lặp mỗi phần tử trong mảng lines
for line in lines:
	print(line)
	## Chuyển 1 line thành các phần nhỏ. Được chia cắt bởi space
	variables = line.split(' ')
	n = variables[0]
	result = variables[1]
	## Thử tính toán bằng hàm sum_to_n. Nếu có lỗi xảy ra trong hàm thì fail test case
	## Nếu tính toán được không có lỗi. Kết quả đúng thì in ra Done. Kết quả sai in ra Fail
	try:
		value = sum_to_n(n)
		if int(result) == int(value):
			print(f"Done test case {line}")
		else:
			print(f"Fail test case {line}")
	except:
		print(f"Fail test case {line}")	